package com.nazirbahrami.smartlock;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import androidx.activity.result.ActivityResultLauncher;

public class MainActivity extends androidx.activity.ComponentActivity {
    private static final String CORRECT_PIN = "123456";
    private static final String QR_SECRET = "NAZIR-BAHRAMI-QR-OPEN-2026";
    private LinearLayout root;
    private EditText pinInput;
    private TextView status;

    private final ActivityResultLauncher<ScanOptions> qrLauncher =
        registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() == null) {
                Toast.makeText(this, "اسکن لغو شد", Toast.LENGTH_SHORT).show();
            } else if (QR_SECRET.equals(result.getContents().trim())) {
                showUnlocked();
            } else {
                Toast.makeText(this, "QR نادرست است", Toast.LENGTH_LONG).show();
            }
        });

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLocked();
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(Color.rgb(25, 40, 55));
        t.setGravity(Gravity.CENTER);
        t.setPadding(12, 16, 12, 16);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private void setupRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(245, 248, 252));
        setContentView(root);
    }

    private void showLocked() {
        setupRoot();
        root.addView(text("NAZIR BAHرامI", 26));
        root.addView(text("SMART LOCK", 20));
        root.addView(text("برای ورود، PIN شش‌رقمی را وارد کنید یا QR چاپ‌شده را اسکن کنید.", 16));
        pinInput = new EditText(this);
        pinInput.setHint("PIN شش‌رقمی");
        pinInput.setInputType(2);
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setTextSize(22);
        root.addView(pinInput, new LinearLayout.LayoutParams(-1, -2));
        Button pinButton = button("باز کردن با PIN");
        root.addView(pinButton);
        pinButton.setOnClickListener(v -> {
            if (CORRECT_PIN.equals(pinInput.getText().toString())) showUnlocked();
            else Toast.makeText(this, "PIN نادرست است", Toast.LENGTH_LONG).show();
        });
        Button scanButton = button("اسکن QR CODE");
        root.addView(scanButton);
        scanButton.setOnClickListener(v -> {
            ScanOptions options = new ScanOptions();
            options.setPrompt("QR چاپ‌شده را داخل کادر قرار دهید");
            options.setBeepEnabled(true);
            options.setOrientationLocked(true);
            options.setDesiredBarcodeFormats(ScanOptions.QR_CODE);
            qrLauncher.launch(options);
        });
        root.addView(text("Developer: Nazir Bahrami  |  Version 1.0", 12));
    }

    private void showUnlocked() {
        setupRoot();
        root.addView(text("قفل برنامه باز شد", 28));
        root.addView(text("خوش آمدید", 20));
        Button lockButton = button("قفل دوباره");
        root.addView(lockButton);
        lockButton.setOnClickListener(v -> showLocked());
    }
}
